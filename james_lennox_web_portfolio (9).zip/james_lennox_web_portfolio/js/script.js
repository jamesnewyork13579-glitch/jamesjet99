// Shared interactions: accessible theme switch, typewriter heading, lightbox and demo form.
(function(){
 const html=document.documentElement;
 const themeSwitch=document.querySelector('#themeSwitch');
 let theme='light';
 try{theme=localStorage.getItem('james-portfolio-theme')||'light';}catch(error){theme='light';}
 html.setAttribute('data-bs-theme',theme);
 if(themeSwitch){themeSwitch.checked=theme==='dark';themeSwitch.addEventListener('change',()=>{const next=themeSwitch.checked?'dark':'light';html.setAttribute('data-bs-theme',next);try{localStorage.setItem('james-portfolio-theme',next);}catch(error){/* Theme remains usable without storage. */}});}
 // Typewriter animation is disabled when reduced motion is requested.
 const target=document.querySelector('.typewrite');
 if(target&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches){const words=JSON.parse(target.dataset.words||'[]');let wi=0,ci=0,del=false;function tick(){if(!words.length)return;const word=words[wi];ci+=del?-1:1;target.textContent=word.slice(0,ci);let wait=del?45:85;if(!del&&ci===word.length){del=true;wait=1100;}else if(del&&ci===0){del=false;wi=(wi+1)%words.length;wait=300;}window.setTimeout(tick,wait);}tick();}
 // Bootstrap modal lightbox reads project details from the selected card.
 const modal=document.getElementById('projectLightbox');
 if(modal){document.querySelectorAll('[data-title]').forEach(button=>button.addEventListener('click',()=>{modal.querySelector('.modal-title').textContent=button.dataset.title;const img=modal.querySelector('.lightbox-image');img.src=button.dataset.image;img.alt=button.dataset.title+' preview';modal.querySelector('.lightbox-description').textContent=button.dataset.description;}));}
 // Static demonstration form validates input locally; it does not transmit data.
 document.querySelectorAll('.needs-validation').forEach(form=>form.addEventListener('submit',event=>{event.preventDefault();event.stopPropagation();form.classList.add('was-validated');const status=form.querySelector('.form-status');if(status)status.textContent=form.checkValidity()?'The form fields are valid. This demonstration form does not send messages.':'Please complete the required fields and check the email address.';}));
})();
